/* $Id: ppc.h,v 1.1 2004/01/12 01:56:15 mikpe Exp $
 * PPC32-specific declarations.
 *
 * Copyright (C) 2004  Mikael Pettersson
 */

#define ARCH_LONG_OPTIONS	\
    { "mmcr0", 1, NULL, 1 }, \
    { "mmcr2", 1, NULL, 2 },
