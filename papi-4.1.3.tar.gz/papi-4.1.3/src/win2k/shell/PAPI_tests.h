// prototypes for WinPAPI routines

// tests
int PAPI_test_zero(void); 
int PAPI_test_first(void); 
int PAPI_test_second(void); 
int PAPI_test_third(void); 
int Nils_System_Info(void);

// winpapi_console
void enterConsole(LPSTR title);
void exitConsole(void);
