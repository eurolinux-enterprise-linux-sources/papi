/*
 * Copyright (c) 2007 Hewlett-Packard Development Company, L.P.
 * Contributed by Stephane Eranian <eranian@hpl.hp.com>
 *
 * This file should never be included directly, use
 * <perfmon/perfmon.h> instead.
 */
#ifndef _PERFMON_SPARC_H_
#define _PERFMON_SPARC_H_

#define PFM_ARCH_MAX_PMCS	1
#define PFM_ARCH_MAX_PMDS	2

#endif /* _PERFMON_SPARC_H_ */
