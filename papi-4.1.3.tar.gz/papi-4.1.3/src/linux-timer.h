long long _linux_get_real_usec( void );
long long _linux_get_real_cycles( void );
long long _linux_get_virt_usec( const hwd_context_t * zero );
long long _linux_get_virt_cycles( const hwd_context_t * zero );
int mmtimer_setup(void);

